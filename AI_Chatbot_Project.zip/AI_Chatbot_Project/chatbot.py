# ==========================================
# RULE-BASED AI CHATBOT
# Internship Project - DecodeLabs
# Developed in Python
# ==========================================

import datetime

print("=" * 50)
print("🤖 Welcome to AI Rule-Based Chatbot")
print("Type 'help' to see commands")
print("Type 'bye' or 'exit' to stop the chatbot")
print("=" * 50)

# Ask user name
name = input("Bot: What is your name? ")
print(f"Bot: Nice to meet you, {name}!\n")

# Continuous loop
while True:
    user = input(f"{name}: ").lower()

    # Greetings
    if user in ["hi", "hello", "hey"]:
        print("Bot: Hello! How can I help you today?")

    # Asking about health
    elif user == "how are you":
        print("Bot: I am doing great! Thanks for asking 😊")

    # Bot introduction
    elif user == "what is your name":
        print("Bot: My name is AI Rule-Based Chatbot.")

    elif user == "who made you":
        print("Bot: I was created by a BSCS student using Python.")

    # Time
    elif user == "time":
        current_time = datetime.datetime.now().strftime("%I:%M %p")
        print("Bot: Current time is", current_time)

    # Date
    elif user == "date":
        current_date = datetime.datetime.now().strftime("%d-%m-%Y")
        print("Bot: Today's date is", current_date)

    # Help command
    elif user == "help":
        print("\nYou can ask these questions:")
        print("- hi / hello")
        print("- how are you")
        print("- what is your name")
        print("- who made you")
        print("- time")
        print("- date")
        print("- about python")
        print("- what is ai")
        print("- bye / exit\n")

    # Python information
    elif user == "about python":
        print("Bot: Python is a popular programming language used in AI, web development, and software development.")

    # AI information
    elif user == "what is ai":
        print("Bot: AI stands for Artificial Intelligence. It allows machines to simulate human intelligence.")

    # User feeling
    elif user == "i am sad":
        print("Bot: Don't worry! Everything will be okay 😊")

    elif user == "thank you":
        print("Bot: You're welcome!")

    # Exit condition
    elif user in ["bye", "exit", "goodbye"]:
        print(f"Bot: Goodbye {name}! Have a great day 😊")
        break

    # Default response
    else:
        print("Bot: Sorry, I don't understand that. Type 'help' to see available commands.")